
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
<!DOCTYPE html>
<html lang="es">
<head>
     <meta charset="utf-8"/>
     <title>Cómo incluir JavaScript en el mismo Programa</title>
	<script language="javascript">
		alert('Mi primer alerta en Script');
	</script>
    
</head>
<body>
     <header> 
	Cómo empezar con JavaScript en aplicaciones PHP
     </header>
     
     <footer>
	 www.ecodeup.com 2017
     </footer> 
</body>
</html>